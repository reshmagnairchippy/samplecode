import React from 'react';
export default class Form extends React.Component{
    constructor(props){
        super(props);
       this.state={
        name:"",
        dob:"",
        cls:"",
        divs:"",
        gen:"",
        nameError:"",
        clsError:"",
    };
    this.changeName= this.changeName.bind(this);
    this.changeDob= this.changeDob.bind(this);
    this.changeClss= this.changeClss.bind(this);
    this.changeDivin= this.changeDivin.bind(this);
    this.changeGend= this.changeGend.bind(this);
    this.onSubmit= this.onSubmit.bind(this);
    
}
  changeName = e =>{
      this.setState({
          name: e.target.value
      });
  };

  changeDob = e =>{
    this.setState({
        dob: e.target.value
    });
};

changeClss = e =>{
    this.setState({
        cls: e.target.value
    });
};

changeDivin = e =>{
    this.setState({
        divs: e.target.value
    });
};

changeGend = e =>{
    this.setState({
        gen: e.target.value
    });
};
validate = () =>{
  let nameError="";
  let clsError="";
  if(!this.state.name){
      nameError="Name cannot be blank";
  }
  
  if(nameError){
      this.setState({nameError});
      return false;
  }
  return true;
};

  onSubmit = (e) =>{
      e.preventDefault();
      const isValid = this.validate();
      if(isValid){
      console.log(this.state);
      window.location.href = "http://localhost:3000/";
      }
  };

 render(){
 return(
     <div class="row">
           <div class="col-sm-6">
             <h1>REGISTRATION FORM</h1> 
               <form>
                   Name<input type="text" value={this.state.name}
                   onChange={e =>this.changeName(e)}/>
                   <div style={{ fontSize:12,color:"red"}}>{this.state.nameError}</div><br/>
                  Date of Birth<input type="date" value={this.state.dob}
                   onChange={e =>this.changeDob(e)} required/><br/><br/>
                  Class<select value={this.state.cls} onChange={e =>this.changeClss(e)}>
                           <option>--Select--</option>
                           <option value="I">I</option>
                           <option value="II">II</option>
                           <option value="III">III</option>
                           <option value="IV">IV</option>
                           <option value="V">V</option>
                           <option value="VI">VI</option>
                           <option value="VII">VII</option>
                           <option value="VIII">VIII</option>
                           <option value="IX">IX</option>
                           <option value="X">X</option>
                           <option value="XI">XI</option>
                           <option value="XII">XII</option>
                       </select><br/><br/>  
                  Division<select value={this.state.divs} onChange={e =>this.changeDivin(e)}>
                           <option>--Select--</option>
                           <option value="A">A</option>
                           <option value="B">B</option>
                           <option value="C">C</option>  
                           </select><br/><br/>   
                  Gender<input type="radio" name="rad" value={this.state.gen}
                   onChange={e =>this.changeGend(e)}/>Male
                         <input type="radio" name="rad" value={this.state.gen}
                   onChange={e =>this.changeGend(e)}/>Female<br/><br/>
                <button type="button" class="btn btn-success"  onClick={e => this.onSubmit(e)}>Submit</button>
               </form>
            </div>

          
        </div>

      );
   }

}